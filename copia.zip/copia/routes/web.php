<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\SessionsController;
use App\Http\Controllers\AdminController;



Route::get('/products/create', [AdminController::Class, 'create'])
->middleware('auth.admin')
->name('products.create');

Route::get('/products', [AdminController::Class, 'index'])
->middleware('auth.admin')
->name('products.index');

Route::get('/registro', [RegisterController::Class, 'create'])
    ->middleware('guest')
    ->name('register.index');

Route::post('/registro', [RegisterController::Class, 'store'])
    ->name('register.store');

Route::get('/login', [SessionsController::Class, 'create'])
    ->middleware('guest')
    ->name('login.index');

Route::post('/login', [SessionsController::Class, 'store'])
    ->name('login.store');




  




    
Route::get('/logout', [SessionsController::Class, 'destroy'])
    ->middleware('auth')
    ->name('login.destroy');


    Route::post('/products/create', [AdminController::Class, 'store'])
    ->middleware('auth.admin')
    ->name('products.store');

    Route::delete('/index/destroy/{titulo}',[AdminController::class, 'destroy']) ->middleware('auth.admin')->name('index.destroy');
    Route::delete('/index/destroy/{titulo}',[ProductsController::class, 'destroy'])->middleware('auth.admin')->name('index.destroy');